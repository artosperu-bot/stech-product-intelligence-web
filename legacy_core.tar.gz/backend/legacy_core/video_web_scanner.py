from __future__ import annotations

from dataclasses import dataclass
from html.parser import HTMLParser
from typing import Any, Callable, Optional
import asyncio
import json
import re
from urllib.parse import urljoin, urlparse, parse_qs

from video_catalog import VideoRecord
from video_parser import VideoDiscovery, VideoSource
from video_relevance import assess_video_relevance
from browser_manager import launch_smart_browser


@dataclass
class ExtractedVideo:
    url: str
    title: str = ''
    thumbnail_url: str = ''
    description: str = ''
    direct: bool = False
    context: str = ''


def _youtube_watch(url: str) -> str:
    text=str(url or '')
    m=re.search(r'youtube\.com/embed/([A-Za-z0-9_-]+)',text)
    if m: return 'https://www.youtube.com/watch?v='+m.group(1)
    return text


class _VideoHTMLParser(HTMLParser):
    def __init__(self, base_url: str):
        super().__init__(convert_charrefs=True)
        self.base_url=base_url
        self.rows:list[ExtractedVideo]=[]
        self._jsonld=False
        self._json_buf:list[str]=[]
        self._video_poster=''
    def handle_starttag(self, tag, attrs):
        d={str(k).casefold():str(v or '') for k,v in attrs}
        tag=tag.casefold()
        if tag=='meta':
            key=(d.get('property') or d.get('name') or d.get('itemprop') or '').casefold()
            if key in {'og:video','og:video:url','og:video:secure_url','twitter:player'}:
                u=d.get('content','').strip()
                if u: self.rows.append(ExtractedVideo(url=urljoin(self.base_url,u),direct=u.lower().split('?',1)[0].endswith(('.mp4','.webm','.mov','.m4v')),context='meta '+key))
        elif tag=='video':
            self._video_poster=urljoin(self.base_url,d.get('poster','')) if d.get('poster') else ''
            u=d.get('src','').strip()
            if u: self.rows.append(ExtractedVideo(url=urljoin(self.base_url,u),thumbnail_url=self._video_poster,direct=True,context='video'))
        elif tag=='source':
            u=d.get('src','').strip(); typ=d.get('type','')
            if u and ('video' in typ.casefold() or u.lower().split('?',1)[0].endswith(('.mp4','.webm','.mov','.m4v'))):
                self.rows.append(ExtractedVideo(url=urljoin(self.base_url,u),thumbnail_url=self._video_poster,direct=True,context='video source'))
        elif tag=='iframe':
            u=d.get('src','').strip()
            if u and any(host in u.casefold() for host in ('youtube.com','youtu.be','vimeo.com')):
                self.rows.append(ExtractedVideo(url=_youtube_watch(urljoin(self.base_url,u)),context='iframe'))
        elif tag=='script' and 'ld+json' in d.get('type','').casefold():
            self._jsonld=True; self._json_buf=[]
    def handle_endtag(self, tag):
        if tag.casefold()=='script' and self._jsonld:
            raw=''.join(self._json_buf).strip(); self._jsonld=False
            if raw:
                try: obj=json.loads(raw)
                except Exception: return
                self._walk_json(obj)
    def handle_data(self,data):
        if self._jsonld: self._json_buf.append(data)
    def _walk_json(self,obj:Any):
        if isinstance(obj,dict):
            typ=obj.get('@type')
            types=typ if isinstance(typ,list) else [typ]
            if any(str(x or '').casefold()=='videoobject' for x in types):
                urls=[]
                for key in ('contentUrl','embedUrl','url'):
                    v=obj.get(key)
                    if isinstance(v,str) and v.strip(): urls.append(v.strip())
                thumb=obj.get('thumbnailUrl')
                if isinstance(thumb,list): thumb=thumb[0] if thumb else ''
                for u in urls:
                    self.rows.append(ExtractedVideo(url=_youtube_watch(urljoin(self.base_url,u)),title=str(obj.get('name') or ''),thumbnail_url=urljoin(self.base_url,str(thumb or '')),description=str(obj.get('description') or ''),direct=u.lower().split('?',1)[0].endswith(('.mp4','.webm','.mov','.m4v')),context='jsonld VideoObject'))
            for v in obj.values():
                if isinstance(v,(dict,list)): self._walk_json(v)
        elif isinstance(obj,list):
            for item in obj: self._walk_json(item)


def extract_video_candidates_from_html(page_url: str, html: str) -> list[ExtractedVideo]:
    parser=_VideoHTMLParser(page_url)
    try: parser.feed(html or '')
    except Exception: pass
    out=[]; seen=set()
    for r in parser.rows:
        if not r.url or r.url in seen: continue
        seen.add(r.url); out.append(r)
    return out


def record_from_source(source: VideoSource, product: dict, *, extracted: ExtractedVideo|None=None, metadata: dict|None=None) -> VideoRecord:
    metadata=metadata or {}; extracted=extracted or ExtractedVideo(url=source.url)
    url=str(metadata.get('webpage_url') or source.url or extracted.url or source.product_page_url)
    title=str(metadata.get('title') or source.title or extracted.title or '')
    desc=str(metadata.get('description') or source.description or extracted.description or '')
    thumb=str(metadata.get('thumbnail') or source.thumbnail_url or extracted.thumbnail_url or '')
    duration=metadata.get('duration') or source.duration_seconds or 0
    try: duration=int(duration or 0)
    except Exception: duration=0
    width=int(metadata.get('width') or 0); height=int(metadata.get('height') or 0)
    ext=str(metadata.get('ext') or '')
    direct_url=str(metadata.get('url') or '') if metadata.get('_type') not in {'playlist','url'} else ''
    source_direct = str(source.url or '').lower().split('?',1)[0].endswith(('.mp4','.webm','.mov','.m4v'))
    if source_direct and not direct_url:
        direct_url = source.url
    drm=bool(metadata.get('has_drm') or False)
    formats=metadata.get('formats') or []
    if formats and any(bool(f.get('has_drm')) for f in formats if isinstance(f,dict)) and not any(not f.get('has_drm') for f in formats if isinstance(f,dict)):
        drm=True
    rel=assess_video_relevance(product=product,title=title,description=desc,source_official=source.official,url=url,page_context=extracted.context)
    return VideoRecord(
        url=url or extracted.url,
        title=title,
        page_url=source.product_page_url,
        source_name=source.source_name,
        source_type=source.source_type,
        video_type=source.video_type,
        official=source.official,
        description=desc,
        duration_seconds=duration,
        thumbnail_url=thumb,
        direct_url=extracted.url if extracted.direct else direct_url,
        extension=ext or (str(source.url).lower().split('?',1)[0].rsplit('.',1)[-1] if source_direct else ('mp4' if extracted.url.lower().split('?',1)[0].endswith('.mp4') else '')),
        width=width,height=height,
        filesize=int(metadata.get('filesize') or metadata.get('filesize_approx') or 0),
        relevance_score=rel.score,
        relevance_bucket=rel.bucket,
        relevance_reasons=', '.join(rel.reasons),
        downloadable=not drm,
        drm=drm,
        status='VALIDO' if rel.bucket!='RECHAZADO' else 'RECHAZADO',
    )


def _extract_ytdlp_info_sync(url: str) -> dict:
    try:
        import yt_dlp
    except Exception:
        return {}
    opts={'quiet':True,'no_warnings':True,'skip_download':True,'noplaylist':True,'extract_flat':False}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info=ydl.extract_info(url,download=False)
            if isinstance(info,dict) and info.get('entries'):
                info=next((x for x in info['entries'] if isinstance(x,dict)),info)
            return info if isinstance(info,dict) else {}
    except Exception:
        return {}


async def _page_candidates(url: str) -> list[ExtractedVideo]:
    try:
        from playwright.async_api import async_playwright
        async with async_playwright() as p:
            browser,_browser_candidate=await launch_smart_browser(p,headless=True)
            try:
                page=await browser.new_page()
                await page.goto(url,wait_until='domcontentloaded',timeout=18000)
                html=await page.content()
                return extract_video_candidates_from_html(page.url or url,html)
            finally:
                await browser.close()
    except Exception:
        return []


async def scan_video_sources(discovery: VideoDiscovery, video_ready: Optional[Callable[[VideoRecord,int,int],None]]=None, progress: Optional[Callable[[str],None]]=None, concurrency:int=3) -> list[VideoRecord]:
    tell=lambda t: progress(t) if progress else None
    sources=discovery.videos or []
    tell(f'Validando {len(sources)} videos y páginas...')
    if not sources: return []
    sem=asyncio.Semaphore(max(1,int(concurrency)))
    async def one(source: VideoSource):
        async with sem:
            results=[]
            target=source.url or source.product_page_url
            info=await asyncio.to_thread(_extract_ytdlp_info_sync,target) if target else {}
            if info:
                results.append(record_from_source(source,discovery.product or {},metadata=info))
            else:
                # Preserve the discovered concrete video even if metadata extraction fails.
                if source.url:
                    results.append(record_from_source(source,discovery.product or {}))
                if source.product_page_url:
                    for item in await _page_candidates(source.product_page_url):
                        meta=await asyncio.to_thread(_extract_ytdlp_info_sync,item.url)
                        results.append(record_from_source(source,discovery.product or {},extracted=item,metadata=meta))
            return results
    tasks=[asyncio.create_task(one(s)) for s in sources]
    out=[]; seen=set(); done=0
    for task in asyncio.as_completed(tasks):
        batch=await task; done+=1
        for rec in batch:
            if not rec.url or rec.url in seen or rec.relevance_bucket=='RECHAZADO': continue
            seen.add(rec.url); out.append(rec)
            if video_ready:
                try: video_ready(rec,len(out),len(sources))
                except Exception: pass
        tell(f'Videos revisados: {done}/{len(sources)} | Válidos: {len(out)}')
    return out
