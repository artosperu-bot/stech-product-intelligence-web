from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable
import json
import re

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment


@dataclass
class ImageRecord:
    url: str
    page_url: str = ''
    source_name: str = ''
    source_type: str = 'OTRA'
    official: bool = False
    width: int = 0
    height: int = 0
    format: str = ''
    content_type: str = ''
    image_type: str = 'PRODUCTO'
    quality: str = 'MEDIA'
    score: float = 0.0
    relevance_score: int = 80
    relevance_bucket: str = 'RECOMENDADA'
    relevance_reasons: str = ''
    sha256: str = ''
    perceptual_hash: str = ''
    filename: str = ''
    local_path: str = ''
    status: str = 'VALIDA'
    alt: str = ''
    payload: bytes = field(default=b'', repr=False, compare=False)


def _clean_component(value: str, fallback: str = 'PRODUCTO') -> str:
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', str(value or '').strip())
    text = re.sub(r'\s+', '_', text)
    text = re.sub(r'_+', '_', text).strip(' .')
    if not text:
        text = fallback
    reserved = {'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}
    if text.upper() in reserved:
        text = '_' + text
    return text[:100]


def safe_product_folder_name(product: dict, requested_identifier: str) -> str:
    for key in ('part_number', 'mpn', 'ean', 'upc', 'gtin', 'sku', 'identificador_solicitado'):
        value = str((product or {}).get(key) or '').strip()
        if value:
            return _clean_component(value)
    return _clean_component(requested_identifier)


def rank_image(record: ImageRecord) -> float:
    # V22.4: exact-product relevance still dominates, with stronger resolution quality gates.
    relevance = int(getattr(record, 'relevance_score', 0) or 0)
    score = relevance * 2.0
    if record.official or record.source_type.upper() == 'FABRICANTE_OFICIAL':
        score += 12
    elif record.source_type.upper() == 'DISTRIBUIDOR':
        score += 8
    elif record.source_type.upper() == 'RETAILER':
        score += 5
    elif record.source_type.upper() == 'MARKETPLACE':
        score += 2
    area = max(0, record.width) * max(0, record.height)
    if area >= 2_000_000:
        score += 20
    elif area >= 1_000_000:
        score += 15
    elif area >= 500_000:
        score += 10
    elif area >= 160_000:
        score += 4
    image_type = record.image_type.upper()
    if 'PRINCIPAL' in image_type:
        score += 15
    elif 'PRODUCTO' in image_type:
        score += 10
    elif 'EMPAQUE' in image_type:
        score += 6
    if 'MARKETING' in image_type or 'DUDOSA' in image_type:
        score -= 25
    if record.quality.upper() == 'ALTA':
        score += 8
    elif record.quality.upper() == 'BAJA':
        score -= 18
    short_side = min(record.width or 0, record.height or 0)
    if short_side and short_side < 300:
        score -= 35
    elif short_side and short_side < 500:
        score -= 18
    return score


def diversify_image_order(records: Iterable[ImageRecord]) -> list[ImageRecord]:
    """Put the best image from each source early, then fill by global rank."""
    ordered = sorted(list(records), key=rank_image, reverse=True)
    best_by_source: dict[str, ImageRecord] = {}
    for record in ordered:
        key = (record.source_name or record.source_type or 'OTRA').strip().casefold()
        if key not in best_by_source:
            best_by_source[key] = record
    first_wave = sorted(best_by_source.values(), key=rank_image, reverse=True)
    first_ids = {id(r) for r in first_wave}
    remainder = [r for r in ordered if id(r) not in first_ids]
    return first_wave + remainder


def select_diverse_top(records: Iterable[ImageRecord], limit: int = 6, max_per_source: int = 3) -> list[ImageRecord]:
    """Choose large recommended images while avoiding one source monopolising TOP."""
    eligible = [
        r for r in records
        if int(getattr(r, 'relevance_score', 0) or 0) >= 80
        and min(int(r.width or 0), int(r.height or 0)) >= 500
    ]
    ordered = diversify_image_order(eligible)
    chosen: list[ImageRecord] = []
    counts: dict[str, int] = {}
    for record in ordered:
        key = (record.source_name or record.source_type or 'OTRA').strip().casefold()
        if counts.get(key, 0) >= max_per_source:
            continue
        chosen.append(record)
        counts[key] = counts.get(key, 0) + 1
        if len(chosen) >= max(0, int(limit)):
            break
    return chosen


def build_image_filename(identifier: str, index: int, image_type: str, image_format: str) -> str:
    ext_map = {'JPEG': 'jpg', 'JPG': 'jpg', 'PNG': 'png', 'WEBP': 'webp', 'GIF': 'gif', 'BMP': 'bmp', 'TIFF': 'tif'}
    ext = ext_map.get(str(image_format or '').upper(), 'jpg')
    return f'{_clean_component(identifier)}__{int(index):02d}__{_clean_component(image_type, "PRODUCTO").upper()}.{ext}'


def _hash_distance(a: str, b: str) -> int:
    try:
        return (int(a, 16) ^ int(b, 16)).bit_count()
    except Exception:
        return 999


def dedupe_by_hash(records: Iterable[ImageRecord]) -> list[ImageRecord]:
    # Sort first so exact/near duplicates keep the most useful source/resolution.
    ordered = sorted(list(records), key=rank_image, reverse=True)
    kept: list[ImageRecord] = []
    seen_sha: set[str] = set()
    seen_perceptual: list[str] = []
    for record in ordered:
        if record.sha256 and record.sha256 in seen_sha:
            continue
        if record.perceptual_hash and any(_hash_distance(record.perceptual_hash, old) <= 4 for old in seen_perceptual):
            continue
        kept.append(record)
        if record.sha256:
            seen_sha.add(record.sha256)
        if record.perceptual_hash:
            seen_perceptual.append(record.perceptual_hash)
    return kept


def _record_json(record: ImageRecord) -> dict:
    data = asdict(record)
    data.pop('payload', None)
    return {
        'archivo': data.pop('filename'),
        'ruta_local': data.pop('local_path'),
        **data,
    }


def export_image_manifest(product: dict, records: list[ImageRecord], folder: Path) -> dict[str, Path]:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    json_path = folder / 'metadata_imagenes.json'
    xlsx_path = folder / 'IMAGENES_RESUMEN.xlsx'

    payload = {'producto': product or {}, 'imagenes': [_record_json(r) for r in records]}
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')

    wb = Workbook()
    ws = wb.active
    ws.title = 'Imágenes'
    headers = ['Archivo','Tipo','Fuente','Tipo fuente','Oficial','Resolución','Calidad','Relevancia','Grupo','Razones','Score','URL imagen','URL página','Estado']
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill('solid', fgColor='D9EAF7')
        cell.alignment = Alignment(horizontal='center')
    for r in records:
        ws.append([
            r.filename, r.image_type, r.source_name, r.source_type, 'SI' if r.official else 'NO',
            f'{r.width}x{r.height}' if r.width and r.height else '', r.quality, r.relevance_score, r.relevance_bucket, r.relevance_reasons, rank_image(r), r.url, r.page_url, r.status,
        ])
    widths = [32,22,24,20,10,14,12,12,14,42,10,55,55,18]
    for i, width in enumerate(widths, 1):
        ws.column_dimensions[chr(64+i)].width = width
    ws.freeze_panes = 'A2'
    wb.save(xlsx_path)
    return {'json': json_path, 'xlsx': xlsx_path}
